<?php
  include('includes/header.php');
  include('includes/sidebar.php');
?>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="admin_dashboard.php">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="category.php">Category</a></li>
          <li class="breadcrumb-item"><a href="#">Add Category</a></li>
        </ol>
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
          <h1 class="h2">Add Category</h1>
          <nav aria-label="breadcrumb">
          <nav aria-label="breadcrumb"></nav></nav>

            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                
              </div>
              <!-- <a class="btn btn-primary" href="add_employee.php">Add Employee</a> -->
            </div>
          </div>
            <div style="width:60%; margin-left:25% ; background-color: #F2F4F4;">
                <div id="msg"></div>
                <form action="" method="post" name="add_category" id="add_category" style="margin:3%; padding: 3%;">
                    <div class="form-group">
                        <lable for="cate_name">Category Name</lable>
                        <input type="text" name="title" id="cate_name" class="form-control" placeholder="Enter Your Category Name"  Required>
                    </div>
                    <div class="form-group">
                        <lable for="desc">Description</lable>
                        <textarea name="desc" id="desc"  name="desc" class="form-control" cols="30" rows="10"  placeholder="Enter Your Category Description" ></textarea>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-success" name="submit" id="submit" placeholder="save">
                    </div>
                </form>
            </div>
        
          <canvas class="my-4" id="myChart" width="900" height="380"></canvas>
          <div class="table-responsive">
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
      new DataTable('#example');
    </script>
    <script>
        $(document).ready(function(){
           $('#submit').click(function(){
                var cate_name=$('#cate_name').val();
                var desc=$('#desc').val();
                if(cate_name==''){
                    alert('Please Enter Company Name..!');
                    return false;
                }
                if(desc==''){
                    alert('Please Enter Description..!');
                    return false;
                }
                var data=$('#add_category').serialize();

                $.ajax({
                    type:"POST",
                    url:"category_add.php",
                    data:data,
                    success:function(data){
                        // alert(data);
                        $('#msg').html(data);
                    }
                });
                //  alert(Admin_Type);
           });
        });
    </script>
  </body>
</html>
