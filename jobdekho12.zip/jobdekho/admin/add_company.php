<?php
  include('includes/header.php');
  include('includes/sidebar.php');
?>
<?php
  include('connection/db.php');
  $query=mysqli_query($con,"select *from admin_login where Admin_Type_id='2'");
?>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="admin_dashboard.php">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="company.php">Company</a></li>
          <li class="breadcrumb-item"><a href="#">Add Company</a></li>
        </ol>
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
          <h1 class="h2">Add Company</h1>
          <nav aria-label="breadcrumb">
          <nav aria-label="breadcrumb"></nav></nav>

            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                
              </div>
              <!-- <a class="btn btn-primary" href="add_employee.php">Add Employee</a> -->
            </div>
          </div>
            <div style="width:60%; margin-left:25% ; background-color: #F2F4F4;">
                <div id="msg"></div>
                <form action="" method="post" name="add_company" id="add_company" style="margin:3%; padding: 3%;">
                    <div class="form-group">
                        <lable for="cname">Company Name</lable>
                        <input type="text" name="cname" id="cname" class="form-control" placeholder="Enter Your Company Name"  Required>
                    </div>
                    <div class="form-group">
                        <lable for="desc">Description</lable>
                        <textarea name="desc" id="desc"  name="desc" class="form-control" cols="30" rows="10"  placeholder="Enter Your Company Description" ></textarea>
                    </div>
                    <div class="form-group">
                        <lable for="admin">Company Admin</lable>
                        <select name="admin" id="admin" class="form-control" placeholder="Enter Company Admin">
                          <?php while($r=mysqli_fetch_array($query)) { ?>
                          <option value="<?php echo $r['Admin_Email']; ?>"><?php echo $r['Admin_Email']; ?></option>
                          <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-success" name="submit" id="submit" placeholder="save">
                    </div>
                </form>
            </div>
        
          <canvas class="my-4" id="myChart" width="900" height="380"></canvas>
          <div class="table-responsive">
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
      new DataTable('#example');
    </script>
    <script>
        $(document).ready(function(){
           $('#submit').click(function(){
                var comp_name=$('#cname').val();
                var desc=$('#desc').val();
                var admin=$('#admin').val();
                if(comp_name==''){
                    alert('Please Enter Company Name..!');
                    return false;
                }
                if(desc==''){
                    alert('Please Enter Description..!');
                    return false;
                }
                if(admin==''){
                    alert('Please Enter Company Admin..!');
                    return false;
                }
                var data=$('#add_company').serialize();

                $.ajax({
                    type:"POST",
                    url:"company_add.php",
                    data:data,
                    success:function(data){
                        // alert(data);
                        $('#msg').html(data);
                    }
                });
                //  alert(Admin_Type);
           });
        });
    </script>
  </body>
</html>
