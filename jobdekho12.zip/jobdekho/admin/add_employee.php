<?php
  include('includes/header.php');
  include('includes/sidebar.php');
  
  
?>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="admin_dashboard.php">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="employer.php">Employers</a></li>
          <li class="breadcrumb-item"><a href="#">Add Employee</a></li>
        </ol>
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
          <h1 class="h2">Add Employees</h1>
          <nav aria-label="breadcrumb">
          <nav aria-label="breadcrumb"></nav></nav>

            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                
              </div>
              <!-- <a class="btn btn-primary" href="add_employee.php">Add Employee</a> -->
            </div>
          </div>
            <div style="width:60%; margin-left:25% ; background-color: #F2F4F4;">
                <div id="msg"></div>
                <form action="" method="post" name="add_employee" id="add_employee" style="margin:3%; padding: 3%;">
                    <div class="form-group">
                        <lable for="fname">Firstname</lable>
                        <input type="text" name="fname" id="fname" class="form-control" placeholder="Enter Your Firstname" Required >
                    </div>
                    <div class="form-group">
                        <lable for="lname">Lastname</lable>
                        <input type="text" name="lname" id="lname" class="form-control" placeholder="Enter Your Lastname" Required >
                    </div>
                    <div class="form-group">
                        <lable for="email">Email</lable>
                        <input type="email" name="email" id="email" class="form-control" placeholder="Enter Your Email" Required >
                    </div>
                    <div class="form-group">
                        <lable for="username">Username</lable>
                        <input type="text"  name="username" id="username" class="form-control" placeholder="Enter Your Username" Required >
                    </div>
                    <div class="form-group">
                        <lable for="password">Password</lable>
                        <input type="password"  name="password" id="password" class="form-control" placeholder="Enter Your Password" Required >
                    </div>
                    <div class="form-group">
    <label for="Admin_Type">Admin Type</label>
    <select name="Admin_type_id" class="form-control" id="Admin_type_id" required>
        <?php
        include('connection/db.php');
        $sql = "SELECT id, Admin_type FROM admin_type";
        $result = mysqli_query($con, $sql);

        if (!$result) {
            die("Query failed: " . mysqli_error($con));
        }

        while ($row = mysqli_fetch_assoc($result)) {
            $id = $row['id'];
            $type_name = $row['Admin_type'];
            echo "<option value='$id'>$type_name</option>";
        }
        ?>
    </select>
</div>

                    <div class="form-group">
                        <input type="submit" class="btn btn-success" name="submit" id="submit" placeholder="save">
                    </div>
                </form>
            </div>
          


          <canvas class="my-4" id="myChart" width="900" height="380"></canvas>

          
          <div class="table-responsive">
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
      new DataTable('#example');
    </script>
    <script>
      $(document).ready(function(){
    $('#username').val('defaultUsername'); // Set default username
    $('#password').val('defaultPassword'); // Set default password
});

        $(document).ready(function(){
    $('#submit').click(function(event){
        event.preventDefault(); // Prevent the form from submitting the traditional way

        var data = $('#add_employee').serialize(); // Serialize the form data

        $.ajax({
            type: "POST",
            url: "employee_add.php",
            data: data,
            success: function(response){
                $('#msg').html(response); // Display the response from the PHP script
            },
            error: function(xhr, status, error){
                $('#msg').html('<div class="alert alert-danger">An error occurred: ' + error + '</div>');
            }
        });
    });
});

    </script>
