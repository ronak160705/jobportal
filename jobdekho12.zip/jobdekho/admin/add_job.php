<?php
  include('includes/header.php');
  include('includes/sidebar.php');
?>
<?php
  include('connection/db.php');
  $query=mysqli_query($con,"select *from job_category");
?>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="admin_dashboard.php">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="job_create.php">All Jobs</a></li>
          <li class="breadcrumb-item"><a href="#">Create Job</a></li>
        </ol>
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
          <h1 class="h2">Create Job</h1>
          <nav aria-label="breadcrumb">
          <nav aria-label="breadcrumb"></nav></nav>

            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                
              </div>
              <!-- <a class="btn btn-primary" href="add_employee.php">Add Employee</a> -->
            </div>
          </div>
            <div style="width:60%; margin-left:25% ; background-color: #F2F4F4;">
                <div id="msg"></div>
                <form action="" method="post" name="add_job" id="add_job" style="margin:3%; padding: 3%;">
                    <div class="form-group">
                        <lable for="jobtitle">Job Title</lable>
                        <input type="text" name="jobtitle" id="jobtitle" class="form-control" placeholder="Enter Job Title" Required >
                    </div>
                    <div class="form-group">
                        <lable for="desc">Description</lable>
                        <textarea name="desc" id="desc"  name="desc" class="form-control" cols="30" rows="10"  placeholder="Enter Job Description" ></textarea>
                    </div>
                    <div class="form-group">
                        <lable for="keyword">Job keyword</lable>
                        <input type="text" name="keyword" id="keyword" class="form-control" placeholder="Enter Job Title" Required >
                    </div>
                    <div class="form-group">
                        <lable for="country">Country</lable>
                        <input type="text" name="country" id="country" class="form-control" placeholder="Enter Country" Required >
                        <!-- <select name="country" class="countries form-control" id="countryId">
                            <option value="" selected>--Select Country--</option>
                            
                        </select> -->
                    </div>
                    <div class="form-group">
                        <lable for="state">State</lable>
                        <input type="text" name="state" id="state" class="form-control" placeholder="Enter State" Required >
                        <!-- <select name="state" class="states form-control" id="stateId">
                            <option value="" selected>--Select State--</option>
                        </select> -->
                    </div>
                    <div class="form-group">
                        <lable for="city">City</lable>
                        <input type="text" name="city" id="city" class="form-control" placeholder="Enter City" Required >
                        <!-- <select name="city" class="cities form-control" id="cityId">
                            <option value="" selected>--Select City--</option>
                        </select> -->
                    </div>
                    <div class="form-group">
                        <lable for="category">Category</lable>
                        <select name="category" class="category form-control" id="category">
                        <option value="">--Select Category--</option>
                          <?php
                            while($r=mysqli_fetch_array($query)){
                          ?>  
                          <option value="<?php echo $r['id']; ?>" Required><?php echo $r['title']; ?></option>
                        <?php  } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-success" name="submit" id="submit" placeholder="save">
                    </div>
                </form>
            </div>
          


          <canvas class="my-4" id="myChart" width="900" height="380"></canvas>

          
          <div class="table-responsive">
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
      new DataTable('#example');
    </script>
    <script>
        $(document).ready(function(){
           $('#submit').click(function(){
                var jobtitle=$('#jobtitle').val();
                var desc=$('#desc').val();
                var country=$('#country').val();
                var state=$('#state').val();
                var city=$('#city').val();
                var keyword=$('#keyword').val();
                var category=$('#category').val();
                if(jobtitle==''){
                    alert('Please Enter Job Title..!');
                    return false;
                }
                if(desc==''){
                    alert('Please Enter Description..!');
                    return false;
                }
                if(country==''){
                    alert('Please Select Country Name..!');
                    return false;
                }
                if(state==''){
                    alert('Please Select State Name..!');
                    return false;
                }
                if(city==''){
                    alert('Please Select City Name..!');
                    return false;
                }
                if(keyword==''){
                    alert('Please Select Keyword..!');
                    return false;
                }
                if(category==''){
                    alert('Please Select Category Name..!');
                    return false;
                }


                var data=$('#add_job').serialize();

                $.ajax({
                    type:"POST",
                    url:"job_add.php",
                    data:data,
                    success:function(data){
                        $('#msg').html(data);
                    }
                });     
           });
        });
    </script>
  </body>
</html>
