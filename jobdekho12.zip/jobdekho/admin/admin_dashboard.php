<?php
 
  require('includes/header.php');
  require('includes/sidebar.php');
?>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h3>DASHBOARD</h3>
          
       
          <!-- <h1 class="h2">Dashboard</h1> -->
            <!-- <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                <button class="btn btn-sm btn-outline-secondary">Share</button>
                <button class="btn btn-sm btn-outline-secondary">Export</button>
              </div>
              <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                This week
              </button>
            </div> -->
          </div>
          <div class="container-fluid" id="main-content">
    <div class="row">
      <div class="col-lg-10 ms-auto p-4 overflow-hidden">
        
        <div class="row mb-4">
          <div class="col-md-3 mb-4">
            <a href="#" class="text-decoration-none">
            <!-- <?php //include('connection/db.php'); $sql=mysqli_query($con,"select * from admin_login where Admin_Type='1'");
             //if($sql){ ?> <?php //}else { echo "<script> alert('You are not valid to Add an Employer..!');</script>"; } ?> -->
              <div class="card text-center text-success p-3">
                <h6>Employers</h6>
                <h1 class="mt-2 mb-0"><?php 
                        include('connection/db.php');
                        $sql=mysqli_query($con,"select * from admin_login where Admin_type_id='2'");
                        $cnt=mysqli_num_rows($sql);
                        echo $cnt;                      
                      ?></h1>
              </div>
            </a>
          </div>
          
          <div class="col-md-3 mb-4">
            <a href="#" class="text-decoration-none">
              <div class="card text-center text-info p-3">
                <h6>New Jobs</h6>
                <h1 class="mt-2 mb-0"><?php 
                        include('connection/db.php');
                        $sql=mysqli_query($con,"select * from jobs");
                        $cnt=mysqli_num_rows($sql);
                        echo $cnt;                      
                      ?></h1>
              </div>
            </a>
          </div>
         
        </div>
 
        <div class="d-flex align-items-center justify-content-between mb-3">
          <h5>Jobs Analytics</h5>
          <!-- <select class="form-select shadow-none bg-light w-auto" onchange="booking_analytics(this.value)">
            <option value="1">Past 30 Days</option>
            <option value="2">Past 90 Days</option>
             <option value="3">Past 1 Year</option>
            <option value="4">All time</option>
          </select> -->
        </div> 

        <div class="row mb-3">
          <div class="col-md-3 mb-4">
            <div class="card text-center text-primary p-3">
              <h6>Job Seekers</h6>
              <h1 class="mt-2 mb-0" id=""><?php 
                        include('connection/db.php');
                        $sql=mysqli_query($con,"select * from jobseeker");
                        $cnt=mysqli_num_rows($sql);
                        echo $cnt;                      
                      ?></h1>             
            </div>
          </div>
          <div class="col-md-3 mb-4">
            <div class="card text-center text-success p-3">
              <h6>Apply Jobs</h6>
              <h1 class="mt-2 mb-0" id=""><?php 
                        include('connection/db.php');
                        $sql=mysqli_query($con,"select * from applyjob");
                        $cnt=mysqli_num_rows($sql);
                        echo $cnt;                      
                      ?></h1>             
            </div>
          </div>
          <div class="col-md-3 mb-4">
            <div class="card text-center text-info p-3">
              <h6>Resume</h6>
              <h1 class="mt-2 mb-0" id=""><?php 
                        include('connection/db.php');
                        $sql=mysqli_query($con,"select * from applyjob");
                        $cnt=mysqli_num_rows($sql);
                        echo $cnt;                      
                      ?></h1>             
            </div>
          </div>
          
        </div>


        <!-- <div class="d-flex align-items-center justify-content-between mb-3">
          <h5>User, Queries, Reviews Analytics</h5>
          <select class="form-select shadow-none bg-light w-auto" onchange="user_analytics(this.value)">
            <option value="1">Past 30 Days</option>
            <option value="2">Past 90 Days</option>
             <option value="3">Past 1 Year</option>
            <option value="4">All time</option> 
          </select>
        </div> -->
      
        <div class="row mb-3">
          <!-- <div class="col-md-3 mb-4">
            <div class="card text-center text-success p-3">
              <h6>New Registration</h6>
              <h1 class="mt-2 mb-0" id="total_new_reg">0</h1>
            </div>
          </div> -->
          
          <!-- <div class="col-md-3 mb-4">
            <div class="card text-center text-primary p-3">
              <h6>Reviews</h6>
              <h1 class="mt-2 mb-0" id="total_reviews">0</h1>
            </div>
          </div> -->
        </div>
  
        <h5>Users</h5>
        <div class="row mb-3">
          <div class="col-md-3 mb-4">
            <div class="card text-center text-info p-3">
              <h6>Total</h6>
              <h1 class="mt-2 mb-0"><?php 
                        include('connection/db.php');
                        $jobs=mysqli_query($con,"select * from jobseeker");
                        $cnt1=mysqli_num_rows($jobs);
                        $comp=mysqli_query($con,"select * from admin_login where Admin_type_id='2'");
                        $cnt2=mysqli_num_rows($comp);
                        echo $cnt1 + $cnt2 ;                      
                      ?></h1>
            </div>
          </div>
          <div class="col-md-3 mb-4">
            <div class="card text-center text-primary p-3">
              <h6>Queries</h6>
              <h1 class="mt-2 mb-0" id="total_queries"><?php 
                        include('connection/db.php');
                        $sql=mysqli_query($con,"select * from contact");
                        $cnt=mysqli_num_rows($sql);
                        echo $cnt;                      
                      ?></h1>
            </div>
          </div>
          <!-- <div class="col-md-3 mb-4">
            <div class="card text-center text-warning p-3">
              <h6>Inactive</h6>
              <h1 class="mt-2 mb-0"></h1>
            </div>
          </div> -->
          
        </div>

      </div>
    </div>
  </div>
          <!-- <canvas class="my-4" id="myChart" width="900" height="380"></canvas> -->

          
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <!-- <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script> -->

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    <!-- Graphs -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.1/dist/Chart.min.js"></script>
    <script>
      // var ctx = document.getElementById("myChart");
      // var myChart = new Chart(ctx, {
      //   type: 'line',
      //   data: {
      //     labels: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      //     datasets: [{
      //       data: [15339, 21345, 18483, 24003, 23489, 24092, 12034],
      //       lineTension: 0,
      //       backgroundColor: 'transparent',
      //       borderColor: '#007bff',
      //       borderWidth: 4,
      //       pointBackgroundColor: '#007bff'
      //     }]
      //   },
      //   options: {
      //     scales: {
      //       yAxes: [{
      //         ticks: {
      //           beginAtZero: false
      //         }
      //       }]
      //     },
      //     legend: {
      //       display: false,
      //     }
      //   }
      // });
    </script>
  </body>
</html>
