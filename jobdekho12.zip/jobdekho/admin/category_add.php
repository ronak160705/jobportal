<?php
    include('connection/db.php');
    
        $cate_name=$_POST['title'];
        $desc=$_POST['desc'];
        
    $sql="insert into job_category (title,Description) values ('$cate_name','$desc')";
    // print_r($sql);
    $res=mysqli_query($con,$sql);
    if($res){
        echo "<script> alert('Data has been inserted successfully');</script>";
    }else{
        echo"<script> alert('Something Went Wrong...!');</script>";
    }

    
?>
