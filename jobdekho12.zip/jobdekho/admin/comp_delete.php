<?php
    include('connection/db.php');

    $del=$_GET['del'];
    $sql="delete from company where Comp_id='$del'";
    $res=mysqli_query($con,$sql);
    if($res){
        echo"<script> alert('Record has been deleted successfully');</script>";
        header('location:company.php');
    }
?>