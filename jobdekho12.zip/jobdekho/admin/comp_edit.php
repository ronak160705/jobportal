<?php
    include('connection/db.php');
    include('includes/header.php');
    include('includes/sidebar.php');
    $edit=$_GET['edit'];
    $sql=mysqli_query($con,"select * from company where Comp_id='$edit'");
    while($r=mysqli_fetch_array($sql)){
        $cname=$r['Company_Name'];
        $desc=$r['Description'];
        $admin=$r['admin'];
        
    }
?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item"><a href="company.php">Company</a></li>
          <li class="breadcrumb-item"><a href="#">Update Company</a></li>
        </ol>
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
          <h1 class="h2">Update Company</h1>
          <nav aria-label="breadcrumb">
          <nav aria-label="breadcrumb"></nav></nav>

            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                
              </div>
              <!-- <a class="btn btn-primary" href="add_employee.php">Add Employee</a> -->
            </div>
          </div>
          <div style="width:60%; margin-left:25% ; background-color: #F2F4F4;">
                <div id="msg"></div>
                <form action="" method="post" name="edit_company" id="edit_company" style="margin:3%; padding: 3%;">
                    <div class="form-group">
                        <lable for="cname">Company Name</lable>
                        <input type="text" name="cname" id="cname"  value="<?php echo $cname; ?>" class="form-control" placeholder="Enter Your Company Name">
                    </div>
                    <div class="form-group">
                        <lable for="desc">Description</lable>
                        <textarea name="desc" id="desc"  name="desc"  value="<?php echo $desc; ?>" class="form-control" cols="30" rows="10"  ></textarea>
                    </div>
                    <div class="form-group">
                        <lable for="admin">Company Admin</lable>
                        <select name="admin" id="admin" class="form-control" placeholder="Enter Company Admin" value="<?php echo $admin; ?>">
                        <?php
                          include('connection/db.php');
                          $query=mysqli_query($con,"select *from admin_login where Admin_Type_id='2'");
                          while($r=mysqli_fetch_array($query)) { ?>
                          <option value="<?php echo $r['Admin_Email']; ?>"><?php echo $r['Admin_Email']; ?></option>
                          <?php } ?>
                        </select>
                    </div>
                    <input type="hidden" name="id" id="id" value="<?php echo $_GET['edit']; ?>">
                    <div class="form-group">
                        <input type="submit" class="btn btn-success" value="Update" name="update" id="update" placeholder="update">
                    </div>
                </form>
            </div>
          


          <canvas class="my-4" id="myChart" width="900" height="380"></canvas>

          
          <div class="table-responsive">
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
      new DataTable('#example');
    </script>
   
  </body>
</html>

<?php
include('connection/db.php');
if(isset($_POST['update'])){
    $id=$_POST['id'];
    $cname=$_POST['cname'];
    $desc=$_POST['desc'];
    $admin=$_POST['admin'];

    $sql="update company set Company_Name='$cname',Description='$desc',Admin='$admin' where Comp_id='$id'";
    print_r($sql);
    $res1=mysqli_query($con,$sql);
    if($res1){
        echo"<script> alert('Record has been updated successfully');</script>";
        header('location:company.php');
    }else{
        echo"<script> alert('Some errors Occurrence Please Try Again..!');</script>";
    }
}

?>
