<?php
    include('connection/db.php');
   
        $cname=$_POST['cname'];
        $desc=$_POST['desc'];
        $admin=$_POST['admin'];
        
    $sql="insert into company (Company_Name,Description,Admin) values ('$cname','$desc', '$admin')";
    // print_r($sql);
    $res=mysqli_query($con,$sql);
    if($res){
        echo "<script>alert('data inserted successfully..!');</script>";
    }else{
        echo"<script>alert('Please Try Again..!');</script>";
    }
    
?>
