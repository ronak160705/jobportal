<?php
    include('connection/db.php');

    $del=$_GET['del'];
    $sql="delete from admin_login where id='$del'";
    $res=mysqli_query($con,$sql);
    if($res){
        echo"<script> alert('Record has been deleted successfully');</script>";
        header('location:employer.php');
    }
?>