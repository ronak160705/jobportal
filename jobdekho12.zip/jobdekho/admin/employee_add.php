<?php
include('connection/db.php');

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['password'];
$username = $_POST['username'];
$admin_type = $_POST['Admin_type_id'];

$sql = "INSERT INTO admin_login (Firstname, Lastname, Admin_Email, Admin_Pass, Admin_Username, Admin_type_id) VALUES ('$fname', '$lname', '$email', '$password', '$username', '$admin_type')";

$res = mysqli_query($con, $sql);

if ($res) {
    echo "<div class='alert alert-success'>Data inserted successfully!</div>";
} else {
    echo "<div class='alert alert-danger'>Please try again!</div>";
}
?>
