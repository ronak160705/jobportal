<?php
// session_start();
  include('connection/db.php');
  //$conn=mysqli_connect("localhost","root","","jobs");
  $sql="select * from admin_login where Admin_Email='{$_SESSION['email']}' and Admin_type_id='1'	";
  //print_r($sql);
  $res=mysqli_query($con,$sql);
  if(mysqli_num_rows($res)>0){
?>
<div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="#">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <!--
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="shopping-cart"></span>
                  Products
                </a>
              </li> -->
              <li class="nav-item">
                <a class="nav-link" href="employer.php">
                  <span data-feather="users"></span>
                  Employers 
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="job_create.php">
                  <span data-feather="bar-chart-2"></span>
                  Job Create
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="company.php">
                  <span data-feather="layers"></span>
                  Company
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="category.php">
                  <span data-feather="file-text"></span>
                  Category
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="user_query.php">
                <span data-feather="help-circle"></span>
                 User Query
                </a>
              </li>
            </ul>

           
          </div>
        </nav>
<?php
    }else{
?>
<div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="#">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              
              <!-- <li class="nav-item">
                <a class="nav-link" href="employer.php">
                  <span data-feather="users"></span>
                  Employers
                </a>
              </li> -->
              <li class="nav-item">
                <a class="nav-link" href="job_create.php">
                  <span data-feather="bar-chart-2"></span>
                  Job Create
                </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" href="apply_job.php">
                  <span data-feather="layers"></span>
                  Apply Jobs
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="user_query.php">
                  <span data-feather="help-circle"></span>
                  User Query
                </a>
              </li>            
              
            </ul>      
            
          </div>
        </nav>
<?php
    }
?>

  