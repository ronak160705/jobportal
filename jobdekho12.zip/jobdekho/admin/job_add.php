<?php
    session_start();
    include('connection/db.php');

    $admin = $_SESSION['email'];
    $jobtitle = $_POST['jobtitle'];
    $desc = $_POST['desc'];
    $country = $_POST['country'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $keyword = $_POST['keyword'];
    $category = $_POST['category']; // Fix this line

    // Insert query
    $sql = "INSERT INTO jobs (Emp_Email, Job_Title, Description, Country, State, City, Keyword, Category) 
            VALUES ('$admin', '$jobtitle', '$desc', '$country', '$state', '$city', '$keyword', '$category')";
    
    $res = mysqli_query($con, $sql);

    if ($res) {
        echo "Data inserted successfully!";
    } else {
        echo "Please try again!";
    }
?>
