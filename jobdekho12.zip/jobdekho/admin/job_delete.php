<?php
    include('connection/db.php');

    $del=$_GET['del'];
    $sql="delete from jobs where Job_id='$del'";
    $res=mysqli_query($con,$sql);
    if($res){
        echo"<script> alert('Record has been deleted successfully');</script>";
        header('location:job_create.php');
    }
?>