<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if (isset($_POST['submit'])) {
    // Email data
    $from = $_POST['from'];
    $sub = $_POST['sub'];
    $body = $_POST['body'];

    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();                                     // Set mailer to use SMTP
        $mail->Host       = 'smtp.gmail.com';                // Specify main SMTP server
        $mail->SMTPAuth   = true;                            // Enable SMTP authentication
        $mail->Username   = 'Ronakvasavada58@gmail.com';           // Your Gmail address
        // Ensure to use an App Password if 2FA is enabled on your Google account
        $mail->Password   = 'RonakVasa@1607';             // App Password or Gmail password if 2FA is off
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;  // Enable TLS encryption
        $mail->Port       = 587;                             // Use port 587 for TLS

        // Recipients
        $mail->setFrom('Ronakvasavada58@gmail.com', 'Your Name');  // Your email and name
        $mail->addAddress($from);                            // Add the recipient's email

        // Email content
        $mail->isHTML(true);                                 // Set email format to HTML
        $mail->Subject = $sub;
        $mail->Body    = $body;

        // Send email
        $mail->send();
        echo "<script>alert('Message has been sent.');</script>";
    } catch (Exception $e) {
        echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');</script>";
    }
}
?>
<!-- HTML Button -->
<button class="btn btn-success btn-lg"><a href="http://localhost/Jobdekho/admin/apply_job.php">Back</a></button>
</body>
</html>
