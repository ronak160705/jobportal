<?php
$to = 'recipient@example.com';
$subject = 'Test Email';
$body = 'Hi, this is a test email sent by a PHP script.';
$headers = 'From: your_email@example.com';

if (mail($to, $subject, $body, $headers)) {
    echo 'Email sent successfully';
} else {
    echo 'Failed to send email';
}
?>
