<?php
    include('connection/db.php');

    $del=$_GET['del'];
    $sql="delete from contact where Cont_id='$del'";
    $res=mysqli_query($con,$sql);
    if($res){
        echo"<script> alert('Contact has been Removed Successfully');</script>";
       echo"<script>
       window.setTimeout(function(){
           window.location.href = 'http://localhost/Jobdekho/admin/user_query.php';
       },1000);
   </script>";
    }
?>