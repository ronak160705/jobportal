<?php
include('includes/header.php');
include('includes/sidebar.php');
?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="admin_dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="#">Send E-mail</a></li>
    </ol>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">Send E-mail</h1>
    </div>
    <div style="width:60%; margin-left:5%; background-color: #F2F4F4; border:1px solid black; padding:3%;">
        <div id="msg"></div>
        <form action="mailer.php" method="post" name="send_mail" id="send_mail">
            <?php
            include('connection/db.php');
            $id = $_GET['id'];

            $sql = "SELECT * FROM applyjob 
                    LEFT JOIN jobs ON applyjob.Job_id = jobs.Job_id
                    WHERE Ap_job_id = '$id'";
            $query = mysqli_query($con, $sql);

            if (!$query) {
                die("Query failed: " . mysqli_error($con));
            }

            if (mysqli_num_rows($query) == 0) {
                echo "<p>No results found.</p>";
            } else {
                while ($r = mysqli_fetch_array($query)) {
                    // Check if keys exist
                    $firstname = isset($r['FirstName']) ? $r['FirstName'] : 'First Name Not Found';
                    $lastname = isset($r['Lastname']) ? $r['Lastname'] : 'Last Name Not Found';
                    $jobseeker = isset($r['JobSeeker_Email']) ? $r['JobSeeker_Email'] : 'Email Not Found';
                    ?>
                    <h2><?php echo strtoupper($firstname); ?> <?php echo strtoupper($lastname); ?></h2><hr>
                    <input type="hidden" name="id" id="id" value="<?php echo $id; ?>">
                    <div class="form-group">
                        <b><label for="to">To :</label></b>
                        <input type="text" name="to" id="to" class="form-control" value="<?php echo $jobseeker; ?>" required>
                    </div>
                    <div class="form-group">
                        <b><label for="from">From :</label></b>
                        <input type="text" name="from" id="from" class="form-control" placeholder="From Email" required>
                    </div>
                    <div class="form-group">
                        <b><label for="sub">Subject :</label></b>
                        <input type="text" name="sub" id="sub" class="form-control" placeholder="Subject of Your Email.." required>
                    </div>
                    <div class="form-group">
                        <b><label for="body">Body :</label></b>
                        <textarea name="body" id="body" class="form-control" cols="30" rows="10" required>Dear <?php echo strtoupper($firstname); ?> <?php echo strtoupper($lastname); ?>
                        </textarea>
                    </div>
                    <?php
                }
            }
            ?>
            <div class="form-group">
                <input type="submit" class="btn btn-primary btn-block" name="submit" id="submit" value="Send">
            </div>
        </form>
    </div>
</main>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>
  feather.replace();
</script>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
  new DataTable('#example');
</script>
</body>
</html>
