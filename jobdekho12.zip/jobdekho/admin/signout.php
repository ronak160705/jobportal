<?php
    session_start();
    session_unset();
    include('connection/db.php');
    $sql="select * from admin_login where Admin_Email='".$_SESSION["email"]."' and Admin_type_id='2'";
    // print_r($sql);
    $query=mysqli_query($con,$sql);
    if($query){
        header('location://localhost/jobdekho/admin/admin_login.php'); 
    }
    else{
        header('location:admin_login.php');
    }
    
?>