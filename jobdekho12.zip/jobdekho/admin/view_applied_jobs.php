<?php
    // session_start();
    include('includes/header.php');
    include('includes/sidebar.php');
?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="admin_dashboard.php">Dashboard</a></li>
        <!-- <li class="breadcrumb-item"><a href="http://localhost/Jobdekho/admin/view_applied_jobs.php?view=<?php echo $_GET['view'];?>">All Apply Jobs</a></li> -->
        <li class="breadcrumb-item"><a href="#">Applied Jobs</a></li>
        </ol>
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Applied Jobs</h1>
            <nav aria-label="breadcrumb">
            <nav aria-label="breadcrumb">
            </nav>
            </nav>
                <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group mr-2"></div>
                </div> 
        </div>         
        <form action="" style="border:1px solid black; width:80%; margin-left :10%; padding: 10px;">
        <?php
        include('connection/db.php');
        $id=$_GET['view'];
        
        $sql="select * from applyjob LEFT JOIN jobs ON applyjob.Job_id =jobs.Job_id
          where Ap_job_id='$id'";
        //  LEFT JOIN jobseeker ON jobseeker.Email =applyjob.JobSeeker LEFT JOIN profile ON profile.User_Email = applyjob.JobSeeker
        $query=mysqli_query($con,$sql);
        while($r=mysqli_fetch_array($query)){
           
        ?>
          <!-- <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">                    
                    <img src="admin/profile_img/rose.jpeg" class="img-thumbnail" alt="MyPic" height="100" width="100">
                  </div>
                </div>
            </div>            -->
                    
            <div class="form-group">
                <label >Job Title :</label>            
                <td><?php echo $r['Job_Title']; ?></td>
            </div>   
            <div class="form-group">
                <label >Description :</label>            
                <td><?php echo $r['Description']; ?></td>
            </div>         
            <div class="form-group">
                <label >Job Seeker Name :</label>            
                <td><?php echo $r['FirstName']; ?> <?php echo $r['Lastname']; ?></td>
            </div>
            <div class="form-group">
                <label >Job Seeker Email :</label>            
                <td><?php echo $r['JobSeeker_Email']; ?></td>
            </div>
            <div class="form-group">
                <label >Mobile Number :</label>            
                <td><?php echo $r['Mobile']; ?></td>
            </div> 
            <div class="form-group">
                <label >Job Seeker Resume :</label>            
                <td><a href="http://localhost/Jobdekho/admin/files/<?php echo $r['ResumeFile'];?>">Download File</a></td>
        </div>           
                 
            <?php } ?>
            <a href="send_mail.php?id=<?php echo $id; ?>" class="btn btn-success">Accept</a>
            <a href="reject_job.php?id=<?php echo $id; ?>" class="btn btn-danger">Reject</a>
           
        </form>
          <canvas class="my-4" id="myChart" width="900" height="380"></canvas>
          <div class="table-responsive">
          </div>
        </main>
      </div>
    </div>

   
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>


    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
      new DataTable('#example');
    </script>
  </body>
</html>
