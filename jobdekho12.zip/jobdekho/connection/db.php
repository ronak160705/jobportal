<?php
// Database connection script

// Server, username, password, database name
$con = mysqli_connect("localhost", "root", "", "job");

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
